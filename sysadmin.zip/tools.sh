#!/bin/bash
chmod 777 sysadmin/tools
./sysadmin/tools | lolcat

