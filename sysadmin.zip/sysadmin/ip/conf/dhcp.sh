#!/bin/bash


read -p "       masukan nama interface anda = " int;
echo 'auto '$int >> /etc/network/interfaces
echo 'iface '$int' inet dhcp'>> /etc/network/interfaces
