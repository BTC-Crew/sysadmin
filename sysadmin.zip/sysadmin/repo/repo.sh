#!/bin/bash

chmod 777 sysadmin/repo/repo
./sysadmin/repo/repo | lolcat
