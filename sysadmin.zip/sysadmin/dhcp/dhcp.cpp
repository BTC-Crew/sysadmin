#include <iostream>

using namespace std;

        int main(){
        system("clear");

        int pilihan;


          system("chmod 777 sysadmin/logo2");
          system("./sysadmin/logo2");

          cout<<"       SILAHKAN PILIH OPSI YANG ANDA INGINKAN"<<'\n'<<'\n';
          cout<<"       1.Konfigurasi dhcp"<<'\n';
          cout<<"       2.Service dhpc"<<'\n';
          cout<<"       3.Dhpc status"<<'\n';
          cout<<"       4.Dhpc stop"<<'\n';
          cout<<"       00.Menu utama"<<'\n'<<'\n'<<'\n';

          cout<<"       SILAHKAN MASUKAN PILIHAN ANDA = ";
          cin>>pilihan;

          

          if(pilihan==1){
              system("chmod 777 sysadmin/dhcp/conf/dhc.sh");
              system("./sysadmin/dhcp/conf/dhc.sh");
              system("./sysadmin/dhcp/dhcpp | lolcat");

          }

          else if(pilihan==2){
              system("/etc/init.d/isc-dhcp-server restart");
              system("./sysadmin/dhcp/dhcpp | lolcat");

          }

          else if(pilihan==3){
              system("/etc/init.d/isc-dhcp-server status");
          }
          
          else if(pilihan==4){
              system("/etc/init.d/isc-dhcp-server stop");
          }

          else if(pilihan==00){
              system("./tools.sh");
          }

          else{
              cout<<"        PILIHAN ANDA TIDAK DI KETAHUI";
          }







 }

