#!/bin/bash

apt install ca-certificates apt-transport-https wget -y
wget -q https://packages.sury.org/php/apt.gpg -o- | apt-key add apt.gpg
echo 'deb https://packages.sury.org/php/ buster main' >> /etc/apt/sources.list
