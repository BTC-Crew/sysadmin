#!/bin/bash

apt install iptables iptables-persistent -y 

read -p "       Masukan nama Interface Gateway anda = " int;
echo 'net.ipv4.ip_forward=1' >> /etc/sysctl.conf
iptables -t nat -A POSTROUTING -o $int -j MASQUERADE
netfilter-persistent save
netfilter-persistent reload
reboot
