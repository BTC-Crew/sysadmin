#include <iostream>
using namespace std;

int main(){
  int pilihan;

  system("clear");
  system("./sysadmin/logo");

    cout<<"   SILAHKAN PILIH OPSI YANG ANDA BUTUHKAN..."<<'\n'<<'\n'<<'\n';
    cout<<"     1.  Install Proftpd"<<'\n';
    cout<<"     2.  Konfigurasi Proftpd"<<'\n';
    cout<<"     3.  Service Layanan FTP"<<'\n';
    cout<<"     4.  Status Proftpd"<<'\n';
    cout<<"     5.  Stop Proftpd"<<'\n';
    cout<<"     88. Menu Utama"<<'\n';
    cout<<"     00. Keluar"<<'\n'<<'\n'<<'\n';
    cout<<"   SILAHKAN INPUTKAN PILIHAN ANDA = ";
    cin>>pilihan;


  if (pilihan==1) {
    system("apt install proftpd -y");
    system("./sysadmin/ftp/ftp.sh");
                
  }


    else if(pilihan==2) {
          system("clear");
          system("./sysadmin/logo");
          int pilihan2;

                      cout<<"   SILAHKAN PILIH OPSI YANG ANDA BUTUHKAN..."<<'\n'<<'\n'<<'\n';
                      cout<<"     1.  Backup file Original Proftpd(Recomended)"<<'\n';
                      cout<<"     2.  Port Default(21)"<<'\n';
                      cout<<"     3.  Coustome Port"<<'\n';
                      cout<<"     4.  ServerName"<<'\n';
                      cout<<"     5.  IPV6(ON/OFF)"<<'\n';
                      cout<<"     6.  User Mode"<<'\n';
                      cout<<"     7.  Anonymous Mode"<<'\n';
                      cout<<"     88  Kembali"<<'\n';
                      cout<<"     00  Menu Utama"<<'\n'<<'\n'<<'\n';
                      cout<<"   SILAHKAN INPUTKAN PILIHAN ANDA = ";
                      cin>>pilihan2;

                      if (pilihan2==1)
                      {
                        system("chmod 777 sysadmin/ftp/conf/backup.sh");
                        system("./sysadmin/ftp/conf/backup.sh");
                        system("./sysadmin/ftp/ftp.sh");
                      }

                      else if(pilihan2==2){
                        system("chmod 777 sysadmin/ftp/conf/p21.sh");
                        system("./sysadmin/ftp/conf/p21.sh");
                        system("./sysadmin/ftp/ftp.sh");
                        
                      }
                      else if(pilihan2==3){
                        system("chmod 777 sysadmin/ftp/conf/cport.sh");
                        system("./sysadmin/ftp/conf/cport.sh");
                        system("./sysadmin/ftp/ftp.sh");
                        
                      }

                                    else if(pilihan2==4){
                                      system("clear");
                                      system("./sysadmin/logo");

                                      int pilihan3;

                                      cout<<"     Pilih opsi anda "<<'\n'<<'\n';
                                      cout<<"     1. Default (Debian) "<<'\n';
                                      cout<<"     2. Custome "<<'\n'<<'\n'<<'\n';
                                      cout<<"     Masukan Pilihan Anda =  ";
                                      cin>>pilihan3;

                                      if(pilihan3==1){
                                      system("chmod 777 sysadmin/ftp/conf/sname.sh");
                                      system("./sysadmin/ftp/conf/sname.sh");
                                      system("./sysadmin/ftp/ftp.sh");

                                      }

                                      else if(pilihan3==2){
                                      system("chmod 777 sysadmin/ftp/conf/cname.sh");
                                      system("./sysadmin/ftp/conf/cname.sh");
                                      system("./sysadmin/ftp/ftp.sh");

                                      }

                                    }

                      else if(pilihan2==5){
                        system("chmod 777 sysadmin/ftp/conf/ipv6.sh");
                        system("./sysadmin/ftp/conf/ipv6.sh");
                        system("./sysadmin/ftp/ftp.sh");
                        
                      }

                      else if(pilihan2==6){
                        system("chmod 777 sysadmin/ftp/d6");
                        system("./sysadmin/ftp/d6 | lolcat");

                      }

                      else if(pilihan2==88) {
                        system("./sysadmin/ftp/ftp.sh");

                      }

                      else if(pilihan2==00) {
                        system("./tools.sh");

                      }
                      else {
                             cout<<"PILIHAN ANDA TIDAK DI TEMUKAN";
                      }



  }

  else if (pilihan==3)
  {
    system("/etc/init.d/proftpd restart");
    system("./ftp/ftp.sh");

  }

  else if (pilihan==4)
  {
    system("/etc/init.d/proftpd status");
    
  }

  else if (pilihan==5)
  {
    system("/etc/init.d/proftpd stop");
    system("./ftp/ftp.sh");

  }


  else if(pilihan==88) {
    system("./tools.sh");
    
  }

  else if(pilihan==00) {
      system("clear");
  } else {
    cout<<"PILIHAN ANDA TIDAK DI TEMUKAN";
  }
}
