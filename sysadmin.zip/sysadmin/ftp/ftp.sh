#!/bin/bash

chmod 777 sysadmin/ftp/ftpp
./sysadmin/ftp/ftpp | lolcat